package com.example.gas_on_go

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
