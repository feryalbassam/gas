import 'package:google_maps_flutter/google_maps_flutter.dart';

String userName = '';
String googleMapKey = 'AIzaSyDqqo8ReK016pMnLrF3DdICvbE53lHw8jc';
const CameraPosition googlePlexInitialPosition = CameraPosition(
  target: LatLng(37.42796133580664, -122.085749655962),
  zoom: 14.4746,
);
